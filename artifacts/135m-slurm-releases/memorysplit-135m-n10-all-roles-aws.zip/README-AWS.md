# MemorySplit 135M N=10 all-role AWS transfer bundle

Source revision: `380c3384a41720d6c93e2e5ec495489b49028a00`

This archive transports all five role-scoped paired-Slurm releases through
Amazon S3 or an AWS instance filesystem. It does not contain AWS credentials,
the external production corpus, checkpoints, or an AWS-native scheduler.

## Transfer with Amazon S3

Upload from a machine with AWS credentials:

```bash
aws s3 cp memorysplit-135m-n10-all-roles-aws.zip s3://YOUR-BUCKET/YOUR-PREFIX/memorysplit-135m-n10-all-roles-aws.zip
```

Download on the target machine:

```bash
aws s3 cp s3://YOUR-BUCKET/YOUR-PREFIX/memorysplit-135m-n10-all-roles-aws.zip .
unzip memorysplit-135m-n10-all-roles-aws.zip -d memorysplit-135m-n10
cd memorysplit-135m-n10
sha256sum -c SHA256SUMS
```

Cross-verify all role releases using the verifier shipped in any role:

```bash
unzip roles/farmshare-lead.zip -d verifier
python verifier/scripts/verify_135m_slurm_releases.py --release-dir roles
```

Each role ZIP contains two assigned seeds; each seed is one Dense/Split90
two-GPU pair. Extract only the intended operator ZIP and follow its
`docs/SLURM-135M-RUNBOOK.md`.

## External launch gates

The production `memorysplit-parallel-corpus-v2` receipt is not included and
remains required. Real site canaries remain required. MIT operators must bind
their discovered Slurm profile. These role packages target paired Slurm; merely
copying this bundle to AWS does not turn them into AWS-native jobs.
