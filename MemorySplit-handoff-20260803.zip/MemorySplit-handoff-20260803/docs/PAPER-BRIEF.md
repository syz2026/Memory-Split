# Memory Split

## The mechanism works, and the hypothesis is null in the regime we tested

Over the past week we ran the first controlled test of the idea that factual
memorization competes with reasoning for parameters in a small model. The
mechanism we built to run that test works, and it is a useful engineering result
in its own right. The hypothesis is null, and the reason is that one of the
three premises it rests on turns out to be false. Offloading facts buys no
reasoning, because the facts were never in the weights for the offload to remove.

There is a second reason to want the architecture regardless of the null. Facts
that live in a database can be swapped without retraining, so one foundation
model can be pointed at many fact sets in turn, which likely lets different
organizations maintain their own customs and traditions against shared weights.

Every figure below comes from `docs/RETAINED-RESULTS.md` or is recomputed from
the committed artifacts under `outputs/`.

---

## 1. The three premises

The claim that filtering facts out of training data buys reasoning is widely
held, and the phi-3 team cites it directly. Stated carefully, it needs all three
of the following to hold.

1. Arbitrary facts occupy parameters in a small model.
2. Masking those facts frees the parameters they occupied.
3. The freed parameters are taken up by reasoning.

Premise 1 fails at every load we ran. Premise 2 fails independently in a second
cohort, on evidence of a different kind. Neither failure requires comparing the
two arms against each other, which matters because the arm contrast carries a
training confound we set out in Section 5.

## 2. Design

We train two models that are identical in initialization, data order,
schedule, hyperparameters, and token budget. They differ in whether the loss
rewards predicting a fact value. Values remain visible in the context and in an
external store throughout, so the split arm can read any fact without being
asked to learn it. The masking costs no additional training FLOPs.

Because we generate the corpus ourselves, the fact load is a controlled dose
with a known information content, and the reasoning tasks are knowledge free by
construction. Biographies carry the facts. A Horn-clause generator and an
iGSM-lite generator carry the reasoning, each checked against an independent
oracle that re-derives every answer.

We ran this at two scales. The 160M sweep crosses three fact loads with two
arms at 3.2B tokens per run, which is roughly 20 tokens per parameter and
therefore compute optimal. The 1B pair on AWS serves as a scaling confirmation,
and we have one seed pair there.

## 3. The mechanism works

With the store attached, the split arm answers questions about entities it has
never read about. It scores 0.996 on fresh-entity lookup at 200,000 entities and
0.000 with the store detached, against 0.002 to 0.008 for the dense runs over
1,500 items per cell. On questions about entities it did read about, the split
arm scores 0.5813 against dense's 0.3080 to 0.3120. The values are therefore
living in the store rather than in the weights, which is what the mechanism was
built to do.

This result stands on its own and does not depend on anything else in the paper.
Facts can be edited without touching weights and deleted by removing a row, at
no measurable cost to general capability and no cost in training compute.

## 4. Premise 1 is false, and it fails worst where crowding should bite hardest

Crowding should be most severe at the heaviest fact load, since that is where
the model is asked to hold the most. Our sweep places the heaviest load exactly
where each fact is seen least. Biographies are about 23 percent of a 3.18B-token
mixture, so the biography budget is fixed at roughly 732M tokens and the
exposures per entity are that budget divided by the entity count. Across the
three loads this gives about 196 exposures per fact at 50,000 entities, 49 at
200,000, and 12 at 800,000.

The consequence is that entity count and exposure count moved against each other
throughout the sweep. Raising the load toward capacity drove exposure down
before capacity was ever approached, so the load that should have crowded
hardest is the load at which the model had the least opportunity to store
anything. A fact seen a handful of times is not memorized, and masking a fact
that was never memorized frees nothing.

Nothing in this sweep came near the capacity that crowding would require.
Allen-Zhu and Li put achievable storage at 2 bits per parameter, which is about
324M bits at 162,220,800 parameters, and each entity in our corpus carries
52.96 bits by construction. Even at 800,000 entities we asked for roughly 13
percent of that ceiling. The 2-bit figure is itself a 1000-exposure result, so
at 12 to 196 exposures the true ceiling is lower and the demand side is the
generous reading.

One asymmetry in the sweep is worth declaring, because it cuts in the
hypothesis's favour rather than ours. The dense arm wrapped its corpus at step
6,080 and re-read 17,571,840 tokens, while the split arm did not, so the dense
arm saw slightly more repetition and slightly less unique text. Repetition
raises memorization, which is the burden the hypothesis says the split arm is
freed from. Both channels therefore bias the comparison toward the hypothesis,
and a null that survives a bias pointing the other way is the stronger for it.

## 5. Premise 2 fails on its own terms

Masking withdraws supervision, and it seems to withdraw much less content than
we assumed. In a matched 40M cohort the split arm reaches 5.4264 nats on the
offloaded positions against the dense arm's 5.0943, recovering 94.2 percent of
dense performance without ever training there. Supervision on those tokens was
worth 5.8 percent of the total, because the values are largely reconstructible
from the text around them. In that corpus each fact appears between 1.04 and
1.55 times, with a median of 1 under every definition we tested, which is the
corpus-level reason nothing could have been memorized in the first place.

### Why we do not rest the result on the arm contrast

Two defects sit between the dense-minus-split comparison and any capacity
reading, and both are properties of the training setup rather than of the
outcome. The loss used mean reduction over surviving targets, so masking 24.89
percent of a document's targets multiplied the weight on every remaining target
by 1.331, and the two arms consequently optimized different objectives.

The matched control also fails structurally, which is the more interesting of
the two. Our preregistration requires the control to match the treatment on mean
masked-span NLL within 20 percent, and on the 21.3B-token operating-point corpus
the treatment measures 1.9598 nats against the control's 1.2712, a gap of 35.1
percent. Relaxing the position tolerance from 0.05 to 1.00 moves the gap only to
23.5 percent, where it asymptotes. Fact values are intrinsically higher-entropy
than anything else in a fixed biography template, so no set of non-value spans
averages 1.96 nats. A further 24.5 percent of control-masked tokens fall inside
the three tokens preceding a value.

This generalizes past our project. Any selective-loss or span-masking design
that pairs a treatment against a count-matched control inherits the same problem
whenever the masked content is intrinsically harder than the material available
to match it, and checking for it costs one CPU pass over the corpus.

## 6. Where the hypothesis remains testable

We are not claiming the null holds everywhere. The conjecture stays live in a
regime where models genuinely do memorize, and reaching it means holding
exposures high while the entity count grows. Our biography budget was fixed, so
raising the entity count automatically lowered exposures per entity, and
separating those two is the point of the experiment we would like to run next.
It must hold exposures at around 200 and scale the token budget with the entity
count rather than against it. We have built that corpus at 996,408 entities and
200 exposures over 21.3B tokens, and it is the first in the project to clear the
full gate set. That is the one regime where the dense arm carries a
real memorization burden, so it is the only place where freed capacity would
refer to something that exists.

## 7. Limits

One seed per cell. The reasoning endpoint has floored at every scale and
difficulty we have tried, which leaves its responsiveness unsettled. The
loss-normalization defect in Section 5 applies to every masked run in the
current catalogue and is fixed going forward.

We had assumed a model shown too many facts would compress them until something
gave way. What it appears to do instead is decline to learn them, and declining
to learn them costs it nothing.

---

# Appendix A. The 1B pair against Gemma 3 1B

Our 1B dense and split models reach a high level of reasoning for their size on
only 8B training tokens. The table below compares both against a
`gemma-3-1b-it-qat-4bit` reference on five held-out Reasoning-Gym families.
Every reasoning item requires emitting many tokens correctly. The exact score
counts an item correct only when the whole output is right, whereas the token
score counts correct output tokens, so a partial answer still contributes.

| Task | Dense exact | Split exact | Dense token | Split token | Gemma exact | Gemma token |
|---|---:|---:|---:|---:|---:|---:|
| rotate matrix | 100.0 | 99.8 | 100.0 | 100.0 | 0.0 | 54.4 |
| binary matrix | 74.4 | 93.8 | 99.8 | 99.9 | 0.0 | 75.4 |
| futoshiki | 37.5 | 18.9 | 99.0 | 98.3 | 0.0 | 63.1 |
| path star | 23.8 | 24.6 | 97.2 | 97.2 | 0.0 | 88.4 |
| spiral matrix | 0.0 | 84.8 | 90.3 | 99.9 | 0.0 | 59.5 |

Both of our models outperform the reference on all five families, despite being
undertrained. Across all fourteen families at step 15,582 the dense arm reaches
26.87 percent exact and the split arm 32.71 percent, against the reference's
7.70 percent zero-shot and 12.11 percent two-shot.

Two qualifications belong with these numbers. The evaluation is in distribution
for our models and out of distribution for the reference, since the held-out
items come from the same generators and carry the same prompt template our
models read throughout training. The reference does clear the format on four of
the fourteen families, reaching 43.8 on course schedule and 54.7 on ransom note,
so its zeros are not simply a parsing failure, but familiarity with the template
likely accounts for part of the margin.

The split arm's aggregate lead over dense is the second qualification. It leads
by 5.8 points over fourteen families and trails by 2.6 points over the ten that
the two-shot condition also ran, and it leads on six of fourteen families
individually. Prequential loss on the same tokens puts the arms level at 0.0022
nats, which fits a few families crossing an acquisition threshold better than it
fits a general difference in reasoning.
